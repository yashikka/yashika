new popoye
use popoye
select * from prep
select [column7] from prep where [column7] is null
update [prep]
set[column7]='customer visit'
where[column7] is null
alter table [prep]
'rename' column [column1] to [start_date]

alter table [prep]
rename [column2] to [stop_date]
alter table [prep]
rename [column3] to [card used]
alter table [prep]
rename column [column4] to [start]
alter table [prep]
rename column [column5] to [stop]
alter  table [prep]
rename column [column6] to [miles]
alter table [prep]
rename column [column7] to [purpose]
