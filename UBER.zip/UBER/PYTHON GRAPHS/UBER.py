import pandas as pd

df = pd.read_csv(filepath_or_buffer="C:\\Users\\dell\\Desktop\\YES2.csv",encoding='latin1')
print(df.head())