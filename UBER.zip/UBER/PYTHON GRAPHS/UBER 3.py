import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv(filepath_or_buffer="C:\\Users\\dell\\Desktop\\YES2.csv",encoding='latin1')
print(df.head())

sns.distplot(df.MILES)

plt.xlabel('Room')
plt.ylabel('MILES')
plt.show()