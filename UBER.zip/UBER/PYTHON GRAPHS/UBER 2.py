import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv(filepath_or_buffer="C:\\Users\\dell\\Desktop\\YES2.csv",encoding='latin1')
print(df.head())
plt.hist(df["PURPOSE*"], histtype='bar', ec='YELLOW')
plt.xlabel('PURPOSE')
plt.ylabel('COUNT')
plt.show()